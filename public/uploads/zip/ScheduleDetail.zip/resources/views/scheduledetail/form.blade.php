@extends('layouts.app')

@section('content')

  <div class="page-content row">
    <!-- Page header -->
    <div class="page-header">
      <div class="page-title">
        <h3> {{ $pageTitle }} <small>{{ $pageNote }}</small></h3>
      </div>
      <ul class="breadcrumb">
        <li><a href="{{ URL::to('dashboard') }}">{{ Lang::get('core.home') }}</a></li>
		<li><a href="{{ URL::to('scheduledetail?return='.$return) }}">{{ $pageTitle }}</a></li>
        <li class="active">{{ Lang::get('core.addedit') }} </li>
      </ul>
	  	  
    </div>
 
 	<div class="page-content-wrapper">

		<ul class="parsley-error-list">
			@foreach($errors->all() as $error)
				<li>{{ $error }}</li>
			@endforeach
		</ul>
<div class="sbox animated fadeInRight">
	<div class="sbox-title"> <h4> <i class="fa fa-table"></i> </h4></div>
	<div class="sbox-content"> 	

		 {!! Form::open(array('url'=>'scheduledetail/save?return='.$return, 'class'=>'form-horizontal','files' => true , 'parsley-validate'=>'','novalidate'=>' ')) !!}
<div class="col-md-12">
						<fieldset><legend> ScheduleDetail</legend>
									
				  <div class="form-group hidethis " style="display:none;"> 
					<label for="ScheduleDetailID" class=" control-label col-md-4 text-left"> 
					{!! SiteHelpers::activeLang('ScheduleDetailID', (isset($fields['ScheduleDetailID']['language'])? $fields['ScheduleDetailID']['language'] : array())) !!}	
					</label>
					<div class="col-md-6">
					  {!! Form::text('ScheduleDetailID', $row['ScheduleDetailID'],array('class'=>'form-control', 'placeholder'=>'',   )) !!} 
					 </div> 
					 <div class="col-md-2">
					 	
					 </div>
				  </div> 					
				  <div class="form-group hidethis " style="display:none;"> 
					<label for="ScheduleID" class=" control-label col-md-4 text-left"> 
					{!! SiteHelpers::activeLang('ScheduleID', (isset($fields['ScheduleID']['language'])? $fields['ScheduleID']['language'] : array())) !!}	
					</label>
					<div class="col-md-6">
					  {!! Form::text('ScheduleID', $row['ScheduleID'],array('class'=>'form-control', 'placeholder'=>'',   )) !!} 
					 </div> 
					 <div class="col-md-2">
					 	
					 </div>
				  </div> 					
				  <div class="form-group  " > 
					<label for="Morning Session Start" class=" control-label col-md-4 text-left"> 
					{!! SiteHelpers::activeLang('Morning Session Start', (isset($fields['FirstSessionStart']['language'])? $fields['FirstSessionStart']['language'] : array())) !!}	
					</label>
					<div class="col-md-6">
					  
				<div class="input-group m-b" style="width:150px !important;">
					{!! Form::text('FirstSessionStart', $row['FirstSessionStart'],array('class'=>'form-control datetime', 'style'=>'width:150px !important;')) !!}
					<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
				</div>
				 
					 </div> 
					 <div class="col-md-2">
					 	
					 </div>
				  </div> 					
				  <div class="form-group  " > 
					<label for="Morning Session End" class=" control-label col-md-4 text-left"> 
					{!! SiteHelpers::activeLang('Morning Session End', (isset($fields['FirstSessionEnd']['language'])? $fields['FirstSessionEnd']['language'] : array())) !!}	
					</label>
					<div class="col-md-6">
					  
				<div class="input-group m-b" style="width:150px !important;">
					{!! Form::text('FirstSessionEnd', $row['FirstSessionEnd'],array('class'=>'form-control datetime', 'style'=>'width:150px !important;')) !!}
					<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
				</div>
				 
					 </div> 
					 <div class="col-md-2">
					 	
					 </div>
				  </div> 					
				  <div class="form-group  " > 
					<label for="Evening Session Start" class=" control-label col-md-4 text-left"> 
					{!! SiteHelpers::activeLang('Evening Session Start', (isset($fields['SecondSessionStart']['language'])? $fields['SecondSessionStart']['language'] : array())) !!}	
					</label>
					<div class="col-md-6">
					  
				<div class="input-group m-b" style="width:150px !important;">
					{!! Form::text('SecondSessionStart', $row['SecondSessionStart'],array('class'=>'form-control datetime', 'style'=>'width:150px !important;')) !!}
					<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
				</div>
				 
					 </div> 
					 <div class="col-md-2">
					 	
					 </div>
				  </div> 					
				  <div class="form-group  " > 
					<label for="Evening Session End" class=" control-label col-md-4 text-left"> 
					{!! SiteHelpers::activeLang('Evening Session End', (isset($fields['SecondSessionEnd']['language'])? $fields['SecondSessionEnd']['language'] : array())) !!}	
					</label>
					<div class="col-md-6">
					  
				<div class="input-group m-b" style="width:150px !important;">
					{!! Form::text('SecondSessionEnd', $row['SecondSessionEnd'],array('class'=>'form-control datetime', 'style'=>'width:150px !important;')) !!}
					<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
				</div>
				 
					 </div> 
					 <div class="col-md-2">
					 	
					 </div>
				  </div> 					
				  <div class="form-group  " > 
					<label for="Day" class=" control-label col-md-4 text-left"> 
					{!! SiteHelpers::activeLang('Day', (isset($fields['Day']['language'])? $fields['Day']['language'] : array())) !!}	
					</label>
					<div class="col-md-6">
					  
					<?php $Day = explode(',',$row['Day']);
					$Day_opt = array( 'Mon' => 'Monday' ,  'Tue' => 'Tuesday' ,  'Wed' => 'Wednesday' ,  'Thu' => 'Thursday' ,  'Fri' => 'Friday' ,  'Sat' => 'Saturday' ,  'Sun' => 'Sunday' , ); ?>
					<select name='Day' rows='5' required  class='select2 '  > 
						<?php 
						foreach($Day_opt as $key=>$val)
						{
							echo "<option  value ='$key' ".($row['Day'] == $key ? " selected='selected' " : '' ).">$val</option>"; 						
						}						
						?></select> 
					 </div> 
					 <div class="col-md-2">
					 	
					 </div>
				  </div> </fieldset>
			</div>
			
			

		
			<div style="clear:both"></div>	
				
					
				  <div class="form-group">
					<label class="col-sm-4 text-right">&nbsp;</label>
					<div class="col-sm-8">	
					<button type="submit" name="apply" class="btn btn-info btn-sm" ><i class="fa  fa-check-circle"></i> {{ Lang::get('core.sb_apply') }}</button>
					<button type="submit" name="submit" class="btn btn-primary btn-sm" ><i class="fa  fa-save "></i> {{ Lang::get('core.sb_save') }}</button>
					<button type="button" onclick="location.href='{{ URL::to('scheduledetail?return='.$return) }}' " class="btn btn-success btn-sm "><i class="fa  fa-arrow-circle-left "></i>  {{ Lang::get('core.sb_cancel') }} </button>
					</div>	  
			
				  </div> 
		 
		 {!! Form::close() !!}
	</div>
</div>		 
</div>	
</div>			 
   <script type="text/javascript">
	$(document).ready(function() { 
		
		 

		$('.removeCurrentFiles').on('click',function(){
			var removeUrl = $(this).attr('href');
			$.get(removeUrl,function(response){});
			$(this).parent('div').empty();	
			return false;
		});		
		
	});
	</script>		 
@stop